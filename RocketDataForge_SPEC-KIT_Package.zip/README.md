# RocketDataForge: pacote para SPEC-KIT

Este pacote contém os documentos de entrada consolidados para iniciar o desenvolvimento orientado a especificação.

## Arquivos

1. `01_PRD_RocketDataForge.md`  
   Requisitos de produto, escopo, riscos, fases e critérios de sucesso.

2. `02_Domain_Model_Specification.md`  
   Bounded contexts, linguagem ubíqua, agregados, invariantes, comandos e eventos.

3. `03_Architecture_Decision_Records_ADR-001-020.md`  
   Vinte decisões arquiteturais iniciais com contexto e consequências.

4. `04_SPEC_KIT_INPUT.md`  
   Prompt mestre pronto para ser usado como entrada no SPEC-KIT, referenciando os três documentos anteriores.

## Uso recomendado

1. Adicione os quatro arquivos ao repositório.
2. Forneça os três documentos normativos ao contexto do agente.
3. Use `04_SPEC_KIT_INPUT.md` como comando inicial.
4. Implemente primeiro o vertical slice definido, sem antecipar módulos futuros.
5. Registre novas decisões como ADRs e atualize a matriz de rastreabilidade.
